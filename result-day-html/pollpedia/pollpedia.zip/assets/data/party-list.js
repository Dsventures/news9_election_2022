var partyList = {
    "up": [
        { "partyName": "BSP", "constNo": 1 },
        { "partyName": "BJP", "constNo": 1 },
        { "partyName": "INC", "constNo": 1 },
        { "partyName": "AP", "constNo": 1 },
        { "partyName": "AAP", "constNo": 1 },
        { "partyName": "AIMIM", "constNo": 1 },
    ],
    "pb": [],
    "mn": [],
    "ga": [],
    "uk": []

}