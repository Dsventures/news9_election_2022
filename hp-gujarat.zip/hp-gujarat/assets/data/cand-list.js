var candList = {
    "up": [
        { "candName": "Shah Alam Urf Guddu Jamali", "constNo": 1 },
        { "candName": "Nawab Kazim Ali Khan", "constNo": 1 },
        { "candName": "Anup Kumar Gupta", "constNo": 1 },
        { "candName": "Brahma Shankar Tripathi", "constNo": 1 },
        { "candName": "Ajay Kapoor", "constNo": 1 },
        { "candName": "Zafar Alam", "constNo": 1 },
    ],
    "pb": [],
    "mn": [],
    "ga": [],
    "uk": []

}